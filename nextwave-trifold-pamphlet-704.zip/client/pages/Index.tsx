import { Mail, Phone, Globe, CheckCircle2 } from 'lucide-react';
import { Wave, DoublelWave } from '@/components/Wave';

export default function Index() {
  return (
    <div className="min-h-screen bg-white print:bg-white">
      {/* Print Styles */}
      <style>{`
        @media print {
          body { margin: 0; padding: 0; }
          .brochure-container { 
            width: 100%;
            margin: 0;
            padding: 0;
            page-break-inside: avoid;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .panel { 
            page-break-inside: avoid;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
        }
        
        @page {
          margin: 0;
          size: A4 landscape;
        }
      `}</style>

      <div className="brochure-container">
        {/* Row 1: Panels 1-3 */}
        <div className="flex flex-row">
          {/* Panel 1: Front Cover */}
          <div className="panel w-1/3 bg-nextwave-dark text-white flex flex-col justify-between p-8 print:p-6 relative overflow-hidden" style={{ minHeight: '100vh' }}>
            <div>
              {/* Logo/Header */}
              <div className="mb-8">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2F3f63c4ddbd50441e8f72ea99193eec33%2F95a98f985572415691b96524b5641445?format=webp&width=400&height=200"
                  alt="Nextwave Promotions Logo"
                  className="w-full max-w-xs mb-4"
                />
              </div>

              <div className="mb-8">
                <p className="text-xl font-bold mb-3">Ride the Next Wave of Brand Visibility!</p>
                <p className="text-sm leading-relaxed opacity-95">
                  Results-driven brand activations that connect businesses with real consumers through strategic, on-the-ground engagement and digital amplification.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Phone size={18} />
                <span className="text-sm font-medium">078 389 4384</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={18} />
                <span className="text-sm font-medium">info@nextwavepromotions.co.za</span>
              </div>
              <div className="flex items-center gap-3">
                <Globe size={18} />
                <span className="text-sm font-medium">www.nextwavepromotions.co.za</span>
              </div>
            </div>
          </div>

          {/* Panel 2: About Us */}
          <div className="panel w-1/3 bg-nextwave-light flex flex-col justify-between p-8 print:p-6 relative overflow-hidden" style={{ minHeight: '100vh' }}>
            <Wave color="#ffffff" opacity={0.3} height={120} className="print:hidden" />

            {/* Curved header */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-nextwave-blue" style={{
              clipPath: 'polygon(0 0, 100% 0, 100% 60%, 0 100%)'
            }}></div>

            <div className="relative z-10 pt-8">
              <h2 className="text-xl font-bold text-nextwave-dark mb-4">ABOUT US</h2>
              
              <p className="text-sm text-gray-700 mb-4 leading-relaxed font-medium">
                Nextwave Promotions is a full-service brand activation and experiential marketing agency based in South Africa. We specialise in bringing brands to life through well-planned, professionally executed promotional campaigns.
              </p>
              
              <p className="text-sm font-semibold text-nextwave-dark italic">
                We don't just promote brands — we build experiences that resonate.
              </p>
            </div>

            {/* Image */}
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F3f63c4ddbd50441e8f72ea99193eec33%2F95384e148f234c1689d8561d0f396c0a?format=webp&width=600&height=400"
              alt="Content Creation Team"
              className="rounded-lg h-40 object-cover w-full"
            />
          </div>

          {/* Panel 3: Why Choose Nextwave */}
          <div className="panel w-1/3 bg-nextwave-blue text-white flex flex-col justify-between p-8 print:p-6 relative overflow-hidden" style={{ minHeight: '100vh' }}>
            <Wave color="#ffffff" opacity={0.08} height={100} className="print:hidden" />

            {/* Curved header */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-white/10" style={{
              clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 70%)'
            }}></div>

            <div className="relative z-10">
              <div className="text-xs font-bold mb-6 tracking-wide opacity-90">WHY CHOOSE NEXTWAVE</div>
              
              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 size={16} className="text-nextwave-blue" />
                  </div>
                  <span className="text-xs font-medium leading-tight">Strategic, results-driven activations.</span>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 size={16} className="text-nextwave-blue" />
                  </div>
                  <span className="text-xs font-medium leading-tight">Professionally trained brand ambassadors.</span>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 size={16} className="text-nextwave-blue" />
                  </div>
                  <span className="text-xs font-medium leading-tight">Strong operational management and reporting.</span>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 size={16} className="text-nextwave-blue" />
                  </div>
                  <span className="text-xs font-medium leading-tight">Seamless integration of field work and digital content.</span>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckCircle2 size={16} className="text-nextwave-blue" />
                  </div>
                  <span className="text-xs font-medium leading-tight">Flexible solutions tailored to your brand objectives.</span>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-white/30">
                <p className="text-xs leading-relaxed">
                  We focus on delivering <span className="font-bold">measurable impact</span>, consistent brand representation, and campaigns that leave a <span className="font-bold">lasting impression</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Row 2: Panels 4-6 */}
        <div className="flex flex-row">
          {/* Panel 4: What We Do */}
          <div className="panel w-1/3 bg-gray-50 flex flex-col justify-between p-8 print:p-6 relative overflow-hidden" style={{ minHeight: '100vh' }}>
            <Wave color="#cffafe" opacity={0.4} height={150} className="print:hidden" />

            {/* Curved header */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-nextwave-blue" style={{
              clipPath: 'polygon(0 0, 100% 0, 100% 60%, 0 100%)'
            }}></div>

            <div className="relative z-10 pt-8">
              <h2 className="text-xl font-bold text-nextwave-dark mb-6">WHAT WE DO</h2>
              
              <div className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 bg-nextwave-blue rounded-full flex items-center justify-center">
                      <CheckCircle2 size={14} className="text-white" />
                    </div>
                    <h3 className="font-bold text-sm text-nextwave-dark">Brand Activations</h3>
                  </div>
                  <p className="text-xs text-gray-600 ml-7 leading-snug">Engaging in-store, on-ground and experiential campaigns that drive awareness and sales.</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 bg-nextwave-blue rounded-full flex items-center justify-center">
                      <CheckCircle2 size={14} className="text-white" />
                    </div>
                    <h3 className="font-bold text-sm text-nextwave-dark">Content Creation</h3>
                  </div>
                  <p className="text-xs text-gray-600 ml-7 leading-snug">High-quality photography and video content designed for digital and social platforms.</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 bg-nextwave-blue rounded-full flex items-center justify-center">
                      <CheckCircle2 size={14} className="text-white" />
                    </div>
                    <h3 className="font-bold text-sm text-nextwave-dark">Influencer & Ambassador Campaigns</h3>
                  </div>
                  <p className="text-xs text-gray-600 ml-7 leading-snug">Strategic management of brand ambassadors to ensure authentic consumer engagement.</p>
                </div>
              </div>
            </div>

            {/* Image */}
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F3f63c4ddbd50441e8f72ea99193eec33%2F1ccc919de89543739e482b68e7a0f2d5?format=webp&width=600&height=400"
              alt="Brand Activation"
              className="rounded-lg h-32 object-cover w-full"
            />
          </div>

          {/* Panel 5: Field Services */}
          <div className="panel w-1/3 bg-nextwave-light flex flex-col justify-between p-8 print:p-6 relative overflow-hidden" style={{ minHeight: '100vh' }}>
            <Wave color="#ffffff" opacity={0.3} height={120} className="print:hidden" />

            {/* Curved header */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-nextwave-blue" style={{
              clipPath: 'polygon(0 0, 100% 0, 100% 60%, 0 100%)'
            }}></div>

            <div className="relative z-10 pt-8">
              <h2 className="text-xl font-bold text-nextwave-dark mb-6">FIELD SERVICES</h2>
              
              <div className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-4 h-4 bg-nextwave-blue rounded-full"></div>
                    <h3 className="font-bold text-sm text-nextwave-dark">Brand Activations</h3>
                  </div>
                  <p className="text-xs text-gray-600 ml-6 leading-snug">Product demos, sampling and consumer engagement activations.</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-4 h-4 bg-nextwave-blue rounded-full"></div>
                    <h3 className="font-bold text-sm text-nextwave-dark">Content Creation</h3>
                  </div>
                  <p className="text-xs text-gray-600 ml-6 leading-snug">On-site content capturing tailored for campaigns and brand use.</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-4 h-4 bg-nextwave-blue rounded-full"></div>
                    <h3 className="font-bold text-sm text-nextwave-dark">Influencer & Ambassador Campaigns</h3>
                  </div>
                  <p className="text-xs text-gray-600 ml-6 leading-snug">Ambassador management to represent brands professionally and consistently.</p>
                </div>
              </div>

              <p className="text-xs text-gray-600 mt-6 pt-4 border-t border-gray-300 leading-snug">
                Each campaign is supported by supervision, coordination and post-campaign reporting to ensure quality and consistency.
              </p>
            </div>

            {/* Image */}
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F3f63c4ddbd50441e8f72ea99193eec33%2F1ccc919de89543739e482b68e7a0f2d5?format=webp&width=600&height=400"
              alt="Field Services Team"
              className="rounded-lg h-32 object-cover w-full"
            />
          </div>

          {/* Panel 6: Brand Values */}
          <div className="panel w-1/3 bg-nextwave-blue text-white flex flex-col justify-between p-8 print:p-6 relative overflow-hidden" style={{ minHeight: '100vh' }}>
            <Wave color="#ffffff" opacity={0.08} height={100} className="print:hidden" />

            {/* Curved header */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-white/10" style={{
              clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 70%)'
            }}></div>

            <div className="relative z-10">
              <div className="text-xs font-bold mb-6 tracking-wide opacity-90">OUR BRAND VALUES</div>
              
              <div className="space-y-3">
                <div>
                  <h3 className="font-bold text-sm mb-1">PROFESSIONALISM</h3>
                  <p className="text-xs opacity-90 leading-snug">Every activation is executed with precision, discipline, and attention to detail.</p>
                </div>

                <div>
                  <h3 className="font-bold text-sm mb-1">CREATIVITY</h3>
                  <p className="text-xs opacity-90 leading-snug">We design engaging experiences that attract attention and spark conversation.</p>
                </div>

                <div>
                  <h3 className="font-bold text-sm mb-1">AUTHENTIC ENGAGEMENT</h3>
                  <p className="text-xs opacity-90 leading-snug">Real interactions that build trust between brands and consumers.</p>
                </div>

                <div>
                  <h3 className="font-bold text-sm mb-1">RELIABILITY</h3>
                  <p className="text-xs opacity-90 leading-snug">We deliver on time, on brief, and to standard — every time.</p>
                </div>

                <div>
                  <h3 className="font-bold text-sm mb-1">IMPACT</h3>
                  <p className="text-xs opacity-90 leading-snug">Our focus is on results that matter to your brand.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Print Instructions */}
      <div className="hidden print:hidden bg-blue-50 border-t border-blue-200 p-6 text-center">
        <h3 className="font-semibold text-blue-900 mb-2">Print Instructions</h3>
        <p className="text-sm text-blue-800">
          Use Ctrl+P (Cmd+P on Mac) to print this brochure. Select "Landscape" orientation and ensure "Print backgrounds" is enabled. 
          Set margins to 0 for best results. The PDF will be optimized for standard A4 tri-fold brochures.
        </p>
      </div>
    </div>
  );
}
