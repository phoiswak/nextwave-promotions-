interface WaveProps {
  color?: string;
  opacity?: number;
  height?: number;
  className?: string;
}

export function Wave({ color = "white", opacity = 0.1, height = 80, className = "" }: WaveProps) {
  return (
    <svg
      className={`absolute bottom-0 left-0 w-full ${className}`}
      viewBox={`0 0 1200 ${height}`}
      preserveAspectRatio="none"
      style={{ opacity }}
    >
      <path
        d={`M0,${height * 0.5} Q300,${height * 0.2} 600,${height * 0.5} T1200,${height * 0.5} L1200,${height} L0,${height} Z`}
        fill={color}
      />
    </svg>
  );
}

export function DoublelWave({ 
  color1 = "white", 
  color2 = "white",
  opacity1 = 0.15,
  opacity2 = 0.1,
  height = 120,
  className = ""
}: { 
  color1?: string; 
  color2?: string;
  opacity1?: number;
  opacity2?: number;
  height?: number;
  className?: string;
}) {
  return (
    <div className={`absolute bottom-0 left-0 w-full ${className}`}>
      <svg
        className="w-full"
        viewBox={`0 0 1200 ${height}`}
        preserveAspectRatio="none"
        style={{ opacity: opacity1 }}
      >
        <path
          d={`M0,${height * 0.4} Q300,${height * 0.1} 600,${height * 0.4} T1200,${height * 0.4} L1200,${height} L0,${height} Z`}
          fill={color1}
        />
      </svg>
      <svg
        className="w-full absolute bottom-0 left-0"
        viewBox={`0 0 1200 ${height}`}
        preserveAspectRatio="none"
        style={{ opacity: opacity2 }}
      >
        <path
          d={`M0,${height * 0.6} Q300,${height * 0.3} 600,${height * 0.6} T1200,${height * 0.6} L1200,${height} L0,${height} Z`}
          fill={color2}
        />
      </svg>
    </div>
  );
}
